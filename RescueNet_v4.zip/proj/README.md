# RescueNet – Durg–Bhilai (v3)

Accident reporting, AI-checked photos, ambulance + hospital matching, and an AI first-aid guide.
Plain HTML/JS front end, FastAPI + SQLite back end. **Demo software: not for real emergency dispatch.**

## Run
Windows: `./run.ps1`  ·  Mac/Linux: `./run.sh`  → open http://127.0.0.1:8000

On first start the console prints the **administrator passwords** (also saved in `ADMIN_CREDENTIALS.txt`).
There are no published demo passwords any more. Users simply create an account on the sign-up tab.

## What changed

| # | Request | What was built |
|---|---|---|
| 1 | AI assistant + minor accidents | The assistant is locked until the user files a report. **Minor** accidents (awake, small cuts/bruises, no warning signs) create a report only: no ambulance, no hospital. The user can still escalate ("condition got worse") or mark it resolved. Answers are short numbered steps with one-tap buttons (Not breathing, Heavy bleeding, Burn…). |
| 2 | AI photo verification | Every photo is checked **before** any resource is allocated. Verdict: *verified* → allocate · *review* → a human decides · *rejected* → report removed automatically (kept for audit, user can appeal). |
| 3 | Cancel ambulance | While the ambulance has not yet picked the patient up, the user can cancel. The ambulance and reserved beds are released, and the nearest hospital that has the needed resources is shown, with distance and directions. |
| 4 | More hospital resources | Reporters choose from 15 resources (emergency, ICU, general ward, OT, ventilator, cardiology, neuro, ortho, burns, paediatrics, maternity, CT, blood bank, dialysis, toxicology). Pre-selected from what they report. Allocation prefers hospitals that have all of them and reserves them. Admins edit all counts. |
| 5 | Secure login | See *Security* below. |
| 6 | Accident roads + chart | "Danger zones" (users) / "Accident hotspots" (admins): road corridors coloured on the map plus a ranked stacked bar chart. |
| 7 | Sticky sidebar | The left menu stays fixed while the page scrolls; more sections were added for both roles. |
| 8 | Mobile | Drawer menu, bottom tab bar, 44 px touch targets, swipeable quick buttons, no horizontal overflow on any page. |

## Security (item 5)
* **Admins are fixed.** The addresses are written once on first start and then locked by database triggers: no admin can be added, removed or re-roled, and nobody can be promoted – not by the API, not by the app's own SQL. The public sign-up always creates `role='user'`, rejects extra fields such as `role`, and refuses admin addresses.
* **Real sessions.** Random 256-bit token in an `HttpOnly`, `SameSite=Strict` (and `Secure` on HTTPS) cookie; only its hash is stored. Sessions survive refresh, expire after 12 h, and can be revoked (log out, log out everywhere, password change).
* **Passwords.** PBKDF2-SHA256, 600 000 rounds, per-user salt, constant-time check, same cost for unknown emails. Policy: 10+ chars, 3 of 4 character classes, not common, must not contain your name/email. Live strength meter.
* **Brute force.** 5 wrong attempts per email+IP → 15-minute lock; also per-email and per-IP limits; sign-up, photo checks and assistant are rate-limited.
* **Web hardening.** CSP, `X-Frame-Options: DENY`, `nosniff`, HSTS on HTTPS, CSRF protection (same-origin check + required header), no API docs in production, and only `css/ js/ icons/ data/` are served.
* Old default `demo123` accounts are retired automatically.

## AI
* **Photo checks (always on, no token):** reused / near-duplicate photo detection, AI-generator metadata (C2PA/IPTC/PNG prompt data), photo timestamp, photo GPS vs pinned location, flat-graphic / screenshot / blank detection, real file-type check.
* **Optional deeper checks:** set `ANTHROPIC_API_KEY` (vision model judges "real emergency scene? AI-generated?") and/or `HF_TOKEN`.
* **First-aid assistant:** 17 curated protocols (`data/firstaid.json`, English + some Hindi keywords) answer instantly and work **offline**. Free-form questions go to an optional model that is told to follow those protocols; with no model configured a safe fallback is shown.

## Limits you should know about (honest list)
1. **Reports, hospitals and ambulances still live in the browser's `localStorage`** (as in the original). The server enforces *accounts, roles, photo checks and the assistant*, but a technical user could edit their own browser data. A production system must move this data and the dispatch logic to the server.
2. The "report first" gate for the assistant is enforced in the UI, not the server, for the same reason.
3. Photo verification is a **risk estimate**, not proof. Thresholds were tuned on synthetic images only; test with real photos before relying on them. Deep checks need an API key and were not exercised against the live services during development.
4. Road accident **history is illustrative sample data** (clearly labelled, can be switched off). Corridor shapes are approximate. Replace `ROADS` in `js/risk.js` with official data.
5. Hospital bed counts and ambulance movement are simulated. The first-aid text is general guidance reviewed against common first-aid practice, not a medical device; have a clinician review it before real use.

## Files
`backend/` security.py · ai_verify.py · assistant.py · main.py  ·  `js/` core · engine · ai · risk · auth · views · pages · app  ·  `data/firstaid.json`
